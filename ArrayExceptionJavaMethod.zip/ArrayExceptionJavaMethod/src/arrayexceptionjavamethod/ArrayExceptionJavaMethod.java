
package arrayexceptionjavamethod;


public class ArrayExceptionJavaMethod {
    
    static void namasebutan(String nama) { //membuat method baru tanpa nilai return(kembali)
        
        System.out.println("Sahabat " + nama + " menjadi anggota kelompok? "); //isi perintah dari method yang dibuat
         
    }
    
    static int penjumlahan(int x, int y) { //membuat method baru dengan nilai return
        return x + y; //memberi nilai return karena menggunakan method bervariabel integer
    }
   
    public static void main(String[] args) {
        String[] kelompok = {"bunga","batang","pohon","daun","biji"}; //membuat array
        
        namasebutan("arif");
        System.out.println(kelompok[4]); //memilih lokasi array
        
        try { //kode untuka mencoba perintah
        System.out.println(kelompok[12]);
                } catch(Exception e) { //apabila error
                    System.out.println("Kesalan pengcodingan"); //maka jalankan perintah
                }
                
        System.out.println(penjumlahan(27, 3)); //menggunakan method penjumlahan yakni untuk menambah angka
        
        
        
        
    }
    
}
